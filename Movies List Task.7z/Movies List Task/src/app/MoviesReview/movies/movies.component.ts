import { Component, OnInit } from '@angular/core';
import * as data from 'src/app/movie.json';
@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {

  constructor() { }
  movieData:any
  moviename:any;
  movieRating:any;
  movieTitle:any;
  movieReview:any;
  releaseYear:any;
  filter:any;
  flag:boolean=true;
  validValue:any;
  movieArray=new Array();;
  review=["good","bad","average"];
  ngOnInit(): void {
    this.movieData=data;
    this.getMovies();
  }
  getMovies(){
    for(var i in this.movieData.movies){
      this.validateMovie(this.movieData.movies[i])
    }
    console.log(this.movieArray)
  }
  validateMovie(movie:any){
    this.flag=true;
  console.log(movie.movieTitle)
    if(movie.movieRating>=0 && movie.movieRating<=5){
      console.log("entered IF")
      this.movieRating=movie.movieRating;
    }
    else
    {    this.movieRating=0
       this.flag=false;}
    if(movie.MovieReleaseYear.length==4)
      this.releaseYear=movie.MovieReleaseYear;
    else{
    this.releaseYear=""
       this.flag=false;}
  for(var i in this.review){
    if(this.review[i]==movie.movieReview){
      this.movieReview = movie.movieReview;
      break;
    }
      else{
       this.movieRating=""
      }
    }
    if(this.flag){
       this.movieArray.push(movie);
    }
    
  }
}
