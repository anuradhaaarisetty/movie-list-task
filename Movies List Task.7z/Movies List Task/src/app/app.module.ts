import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
//import { Pipe } from '@angular/core';
import { MoviesComponent } from './MoviesReview/movies/movies.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {MatIconModule} from '@angular/material/icon';
//import{MovieListComponent} from './MoviesReview/movie-list/movie-list-component'

@NgModule({
  declarations: [
    AppComponent,
    MoviesComponent,
    //MovieListComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    Ng2SearchPipeModule,
    MatIconModule,
    //Pipe,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
