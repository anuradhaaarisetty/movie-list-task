export const movies=[
    {
        "movieTitle":"Sherlock Homes 43",
        "movieReview":"good",
        "movieRating":5,
        "MovieReleaseYear":"2019",
        "Image":"/assets/images/Sherlock Homes.jpg"
    },
    {
        "movieTitle":"Avatar",
        "movieReview":"average",
        "movieRating":3.5,
        "MovieReleaseYear":"2017",
        'Image':"/assets/images/Aavatar.jpg"
    },
    {
        "movieTitle":"sfgd",
        "movieReview":"aver",
        "movieRating":95,
        "MovieReleaseYear":"2017",
        'Image':"/assets/images/Aavatar.jpg"
    },
    {
        "movieTitle":"I",
        "movieReview":"gool",
        "movieRating":73,
        "MovieReleaseYear":"2019",
        'Image':"/assets/images/I.jpg"
    },
    {
        "movieTitle":"Big Jake",
        "movieReview":"bad",
        "movieRating":2.3,
        "MovieReleaseYear":"2009",
        'Image':"/assets/images/Big Jake.jpg"
    }

    ]